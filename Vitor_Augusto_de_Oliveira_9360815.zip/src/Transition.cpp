#include <Transition.hpp>

Transition::Transition(int src, int dst, char edge) : source(src), dest(dst), edge(edge) {}